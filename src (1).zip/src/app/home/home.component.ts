import { Component, OnInit } from '@angular/core';
import { ElementRef } from '@angular/core';
import { Renderer2 } from '@angular/core';

import { from } from 'rxjs';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  title="PHOENIX BANK"
  opened= false;

  toggleSideBar()
  {
    this.opened= !this.opened;
  }
  
  
  
  
  
  
  
  
  data=[
    {
      name:'CURRENT ACCOUNT',
     
    },
    {
      name:'FIXED DIPOSITE',
     
    },
    {
      name:'DMAT ACCOUNT',
    
    },
    {
      name:'PERSONAL LOAN',
  
    }
  ]

  

  constructor(private el: ElementRef, private renderer:Renderer2){}

  ngAfterViewInit(){

this.renderer.setStyle(this.el.nativeElement.ownerDocument.body,'backgroundColor', 'abisque');

}
photo:string="./assets/img/download.jpg"
  ngOnInit(): void {
  }

}
