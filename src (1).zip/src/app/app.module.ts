import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule, routingcomponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { HomeComponent } from './home/home.component';
import { SigninComponent } from './signin/signin.component';
import { SidebarModule } from 'ng-sidebar';
import { FixedComponent } from './fixed/fixed.component';
import { EMIComponent } from './emi/emi.component';
import { LoanComponent } from './loan/loan.component';
import {HttpClientModule} from '@angular/common/http';
import { SerComponent } from './ser/ser.component';
import { UtilityService } from './utility.service';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    routingcomponents,
    SignUpComponent,
    SigninComponent,
    HomeComponent,
    FixedComponent,
    EMIComponent,
    LoanComponent,
    SerComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SidebarModule.forRoot(),
    HttpClientModule   
   
  ],
  providers: [UtilityService],
  bootstrap: [AppComponent]
})
export class AppModule { }
