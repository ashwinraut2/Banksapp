import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-fixed',
  templateUrl: './fixed.component.html',
  styleUrls: ['./fixed.component.css']
})
export class FixedComponent implements OnInit {
title="hello"
  constructor(private http:HttpClient) {

   }
onsend()
{
  this.http.post("http://localhost:8082/chat",{messasge:'hello'},{responseType:'json'})
}
  ngOnInit(): void {
  }

}
