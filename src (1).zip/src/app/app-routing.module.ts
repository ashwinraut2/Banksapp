import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EMIComponent } from './emi/emi.component';
import { FixedComponent } from './fixed/fixed.component';
import { HomeComponent } from './home/home.component';
import { LoanComponent } from './loan/loan.component';
import { SerComponent } from './ser/ser.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { SigninComponent } from './signin/signin.component';

const routes: Routes = [
  { path: 'SignUp', component:SignUpComponent},

  { path: 'SignIn', component:SigninComponent},
  { path: 'Home', component:HomeComponent},
  { path: 'fixed-deposite', component:FixedComponent},
  { path: 'EMI', component:EMIComponent},
  { path: 'loan', component:LoanComponent},
  { path: 'cal', component:SerComponent},
  { path: 'loan', component:LoanComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingcomponents=[HomeComponent,SignUpComponent,SigninComponent, LoanComponent,
  LoanComponent,SerComponent,FixedComponent,EMIComponent]